For Hanan ♡
Open index.html in Chrome. All photos are embedded inside the HTML, so they should display even when opened from your phone.
